    <footer>
        <div class="footer-content">
            &copy; MDIS&M Lab, 2025
        </div>
    </footer>
</div><!-- #wrapper -->
<?php wp_footer(); ?>
</body>
</html>