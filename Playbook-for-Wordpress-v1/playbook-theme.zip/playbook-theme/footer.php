<?php
/**
 * Футер темы Playbook (минимальная версия)
 * 
 * @package Playbook
 */

if (!defined('ABSPATH')) {
    exit; // Запрет прямого доступа
}
?>

</main><!-- .playbook-main -->

<footer class="playbook-footer">
    <div class="footer-copyright">
        &copy; 2025 Terre & Co
    </div>
</footer>

<?php wp_footer(); ?>

</body>
</html>